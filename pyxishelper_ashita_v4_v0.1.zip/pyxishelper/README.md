# PyxisHelper for Ashita v4

Helper for Abyssea **Sturdy Pyxides**. It watches the normal NPC menu packet and prints a recommendation in chat. It does **not** auto-click or auto-open the chest.

## Features

- **Red:** reads pressure + target range and recommends the best lever direction/notch count.
- **Gold:** attempts to read the hidden two-digit lock number from the event parameters.
- **Blue:** recommends Higher/Lower based on the current number.
- **Debug:** prints raw P1-P8 values so the parser can be adjusted if retail differs.

## Install

Copy the `pyxishelper` folder to `<Ashita>\addons\pyxishelper\`, then run:

    /addon load pyxishelper

## Commands

    /pyxis on
    /pyxis off
    /pyxis debug
    /pyxis last
    /pyxis red 98 49 67

For the first test, if it says "not recognized" or gives nonsense, enable `/pyxis debug`, reopen the chest, and send the P1-P8 output.
