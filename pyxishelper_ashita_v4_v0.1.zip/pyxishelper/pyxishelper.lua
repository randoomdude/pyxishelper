addon.name = 'pyxishelper';
addon.author = 'OpenAI';
addon.version = '0.1.0';
addon.desc = 'Abyssea Sturdy Pyxis helper for Ashita v4.';

require 'common';
local chat = require 'chat';

local state = { enabled = true, debug = false, last = nil };
local wear_max = { [0] = 5, [1] = 10, [2] = 15, [3] = 30 };

local function out(kind, s)
    local h = chat.header(addon.name);
    if kind == 'good' then print(h:append(chat.success(s)));
    elseif kind == 'warn' then print(h:append(chat.warning(s)));
    elseif kind == 'err' then print(h:append(chat.error(s)));
    else print(h:append(chat.message(s))); end
end

local function parse_params(data)
    local p = {};
    for i = 0, 7 do
        p[i + 1] = struct.unpack('I', data, 0x08 + (i * 4) + 1);
    end
    return p;
end

local function fmt_params(p)
    local t = {};
    for i = 1, 8 do t[#t + 1] = ('P%d=%u'):fmt(i, p[i] or 0); end
    return table.concat(t, '  ');
end

local function red_probability(current, low, high, wear, dir, notches)
    local extra_max = wear_max[wear] or 30;
    local base = notches * 10;
    local hits, total = 0, extra_max + 1;
    local center, dist = (low + high) / 2, 0;
    for extra = 0, extra_max do
        local np = current + dir * (base + extra);
        if np >= low and np <= high then hits = hits + 1; end
        dist = dist + math.abs(np - center);
    end
    return hits / total, dist / total;
end

local function solve_red(current, low, high, wear, tries_left)
    if current >= low and current <= high then
        return 'Pressure is already in range; use the unlock/confirm option.';
    end
    local choices = {};
    for _, d in ipairs({ {-1,'DOWN'}, {1,'UP'} }) do
        for n = 1, 3 do
            local prob, avgdist = red_probability(current, low, high, wear, d[1], n);
            choices[#choices + 1] = { prob=prob, avgdist=avgdist, label=('%s %d notch%s'):fmt(d[2], n, n == 1 and '' or 'es') };
        end
    end
    table.sort(choices, function(a,b)
        if math.abs(a.prob-b.prob) > 0.000001 then return a.prob > b.prob; end
        return a.avgdist < b.avgdist;
    end);
    local b = choices[1];
    return ('Best move: %s | ~%d%% one-move success | wear variance +0..%d | tries left %d')
        :fmt(b.label, math.floor(b.prob*100+0.5), wear_max[wear] or 30, tries_left or 0);
end

local function solve_blue(current, needed, failed, allowed)
    local higher = math.max(0, 99-current);
    local lower = math.max(0, current-10);
    local pick, chance;
    if higher >= lower then pick, chance = 'HIGHER', higher/90;
    else pick, chance = 'LOWER', lower/90; end
    return ('Best guess: %s | current %d | %.1f%% chance | needed %d | failed %d/%d')
        :fmt(pick, current, chance*100, needed or 0, failed or 0, allowed or 5);
end

local function classify(p)
    local low = bit.band(p[3], 0xFFFF);
    local high = bit.rshift(p[3], 16);
    if high > 0 and high <= 200 and low <= high and p[2] <= 200 and p[5] == 5 then return 'red'; end
    if p[2] == 11 and p[3] >= 11 and p[3] <= 99 and p[4] == 5 and p[6] >= p[2] and p[6] <= p[3] then return 'gold'; end
    if p[2] >= 10 and p[2] <= 99 and p[6] == 5 then return 'blue'; end
    return 'unknown';
end

local function handle_pyxis(p)
    local kind = classify(p);
    state.last = { kind=kind, p=p };
    if state.debug then out('msg', ('Detected %s: %s'):fmt(kind, fmt_params(p))); end

    if kind == 'red' then
        local current = p[2];
        local low = bit.band(p[3], 0xFFFF);
        local high = bit.rshift(p[3], 16);
        local tries = math.max(0, p[5]-p[6]);
        out('warn', ('RED PYXIS: Pressure %d | Target %d-%d'):fmt(current, low, high));
        out('good', solve_red(current, low, high, p[4], tries));
    elseif kind == 'gold' then
        local tries = math.max(0, p[4]-p[5]);
        out('warn', ('GOLD PYXIS: Range %d-%d | tries left %d'):fmt(p[2],p[3],tries));
        out('good', ('Code from event parameters: %d'):fmt(p[6]));
        out('msg', 'If that code does not match retail, enable /pyxis debug and send me the P1-P8 line.');
    elseif kind == 'blue' then
        out('warn', 'BLUE PYXIS');
        out('good', solve_blue(p[2],p[4],p[5],p[6]));
    else
        out('warn', 'Sturdy Pyxis detected, but this menu layout was not recognized.');
        out('msg', 'Use /pyxis debug, reopen it, and send me the P1-P8 line.');
    end
end

ashita.events.register('packet_in', 'packet_in_cb', function(e)
    if not state.enabled or e.injected or e.id ~= 0x034 then return; end
    local data = e.data_modified or e.data;
    if data == nil then return; end

    local npc_index = struct.unpack('H', data, 0x28 + 1);
    local ent = GetEntity(npc_index);
    local is_pyxis = ent ~= nil and ent.Name == 'Sturdy Pyxis';
    if not is_pyxis then
        local tidx = AshitaCore:GetMemoryManager():GetTarget():GetTargetIndex(0);
        local t = GetEntity(tidx);
        is_pyxis = t ~= nil and t.Name == 'Sturdy Pyxis';
    end
    if not is_pyxis then return; end

    local ok, p = pcall(parse_params, data);
    if not ok then out('err', 'Failed to parse the Sturdy Pyxis menu packet.'); return; end
    handle_pyxis(p);
end);

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if #args == 0 then return; end
    local c = args[1]:lower();
    if c ~= '/pyxis' and c ~= '/pyxishelper' then return; end
    e.blocked = true;

    local sub = (#args >= 2) and args[2]:lower() or 'help';
    if sub == 'on' then state.enabled=true; out('good','Enabled.'); return; end
    if sub == 'off' then state.enabled=false; out('warn','Disabled.'); return; end
    if sub == 'debug' then state.debug=not state.debug; out('good',('Debug %s.'):fmt(state.debug and 'ON' or 'OFF')); return; end
    if sub == 'last' then
        if state.last then out('msg', ('Last: %s  %s'):fmt(state.last.kind, fmt_params(state.last.p)));
        else out('warn','No Sturdy Pyxis captured yet.'); end
        return;
    end
    if sub == 'red' and #args >= 5 then
        local cur,lo,hi = tonumber(args[3]),tonumber(args[4]),tonumber(args[5]);
        local wear = tonumber(args[6]) or 3;
        if cur and lo and hi then out('good', solve_red(cur,lo,hi,wear,5));
        else out('err','Usage: /pyxis red <current> <low> <high> [wear 0-3]'); end
        return;
    end

    out('msg','Interact with a Sturdy Pyxis normally; recommendations print automatically.');
    out('msg','Commands: /pyxis on | off | debug | last');
    out('msg','Manual red solver: /pyxis red 98 49 67 [wear 0-3]');
end);
